# Lielais-leciens :zap:
Kods,kas izmēra ,cik augstu uzleci un novērtē  lecienu.
## Apraksts
Ir interesants veids, kā cilvēki varēs parbaudīt cik augstu viņi var uzlket un redzēs vai viņu leciens ir labs vai slikts,
Būs iespēja uzstādīt jaunu skolas rekordu un viss labākais lecējs saņems balvu.
## Saturs

## Instalēšana

## Lietošanas instrukcija
Nostājies blakus sensoram un lec, pārbaudi savas lekšanas prasmes.
